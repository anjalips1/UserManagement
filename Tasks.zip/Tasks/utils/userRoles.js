module.exports={
    ADMIN:0,
    USER:1,
   
}